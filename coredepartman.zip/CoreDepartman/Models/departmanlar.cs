﻿
using System.ComponentModel.DataAnnotations;

namespace CoreDepartman.Models
{
    public class departmanlar
    {
        [Key]
        public int ID { get; set; }
        public string departmanad { get; set; }
       
    }
}
