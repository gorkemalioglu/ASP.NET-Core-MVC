﻿using Microsoft.AspNetCore.Mvc;
using CoreDepartman.Models;

namespace CoreDepartman.Controllers
{
    public class departController : Controller
    {
        private readonly Context _context;

        // Constructor Injection
        public departController(Context context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var degerler = _context.departmanlars.ToList();
            return View(degerler);
        }
        [HttpGet]
        public IActionResult YeniDepartman()
        { 
            return View();
        }
        [HttpPost]
        public IActionResult YeniDepartMan(departmanlar d) 
        { 
            _context.departmanlars.Add(d);
            _context.SaveChanges();
            return RedirectToAction("Index");
          
        }
        public IActionResult DepartmanSil(int id)
        {
            var dep=_context.departmanlars.Find(id);
            _context.departmanlars.Remove(dep);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult DepartmanGetir(int id)
        {
            var depart = _context.departmanlars.Find(id);
            return View("DepartmanGetir",depart);
        }
        public IActionResult DepartmanGuncelle(departmanlar d)
        {
            var dep = _context.departmanlars.Find(d.ID);
            dep.departmanad=d.departmanad;
            _context.SaveChanges();
            return RedirectToAction("Index");

        }

    }
}
