﻿using Microsoft.AspNetCore.Mvc;
using CoreDepartman.Models;

namespace CoreDepartman.Controllers
{
    public class departController : Controller
    {
        private readonly Context _context;

        // Constructor Injection
        public departController(Context context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var degerler = _context.Departmans.ToList();
            return View(degerler);
        }
        [HttpGet]
        public IActionResult YeniDepartman()
        { 
            return View();
        }
        [HttpPost]
        public IActionResult YeniDepartMan(Departman d) 
        { 
            _context.Departmans.Add(d);
            _context.SaveChanges();
            return RedirectToAction("Index");
          
        }
        public IActionResult DepartmanSil(int Id)
        {
            var dep=_context.Departmans.Find(Id);
            _context.Departmans.Remove(dep);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult DepartmanGetir(int Id)
        {
            var depart = _context.Departmans.Find(Id);
            return View("DepartmanGetir",depart);
        }
        public IActionResult DepartmanGuncelle(Departman d)
        {
            var dep = _context.Departmans.Find(d.Id);
            dep.Ad=d.Ad;
            _context.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult DepartmanDetay(int Id)
        {
            var degerler=_context.Personels.Where(x =>x.DepartmanlarId==Id).ToList();
            var departad = _context.Departmans.Where(x => x.Id == Id).Select(y => y.Ad).FirstOrDefault();
            ViewBag.dprt=departad;
            return View(degerler);
        }

    }
}
