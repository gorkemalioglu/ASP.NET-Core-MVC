﻿using CoreDepartman.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CoreDepartman.Controllers
{
    [Authorize]
    public class PersonelController : Controller
    {
        private readonly Context _context;
        

        public PersonelController(Context context) // Context'i enjekte ediyoruz
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var degerler = _context.Personels.Include(x=>x.Departman).ToList();
            return View(degerler);
        }
        [HttpGet]
        public IActionResult YeniPersonel()
        {
            List<SelectListItem> degerler = (from x in _context.Departmans.ToList()
                                             select new SelectListItem
                                             {
                                                 Text = x.Ad,
                                                 Value = x.Id.ToString()
                                             }).ToList();
            ViewBag.dgr=degerler;
            return View();
        }
        public IActionResult YeniPersonel(Personel p)
        {
            var per=_context.Departmans.Where(x=>x.Id==p.Departman.Id).FirstOrDefault();
            p.Departman = per;
            _context.Personels.Add(p);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        
    }
}
